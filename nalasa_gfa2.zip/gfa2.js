var operation;
var answer;

var Num1 = 0;
function numOne(){
    Num1 = document.getElementById("num1").value;
} 

var Num2 = 0;
function numTwo(){
    Num2 = document.getElementById("num2").value;
}

var answer;
var op;
var input;

function add(){
    input = "+";
    op = "sum"
    finalAnswer();
}

function sub(){
    input = "-";
    op = "difference"
    finalAnswer();
}

function mul(){
    input = "*";
    op = "product";
    finalAnswer();
}

function div(){
    input = "/";
    op = "quotient";
    finalAnswer();
}

function per(){
    input = "%";
    op = "remainder";
    finalAnswer();
}


function finalAnswer(){ 
    operation = input;
    
    if(operation == "+"){
        answer = parseInt(Num1) + parseInt(Num2);
    }
    if(operation == "-"){
        answer = parseInt(Num1) - parseInt(Num2);
    }
    if(operation == "*"){
        answer = parseInt(Num1) * parseInt(Num2);
    }
    if(operation == "/"){
        answer = parseInt(Num1) / parseInt(Num2);
        answer = answer.toFixed(2);
    }
    if(operation == "%"){
        answer = parseInt(Num1) % parseInt(Num2);
    }


    if(operation == "%" || operation == "/"){
        document.getElementById("FA").innerHTML = ("The " + op + " of " + Num1 + " divided by " + Num2 + " is " + answer);
    }
    else{
        document.getElementById("FA").innerHTML = ("The " + op + " of " + Num1 + " and " + Num2 + " is " + answer);   
    }
    event.preventDefault();
}



